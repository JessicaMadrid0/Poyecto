package com.systempaymentut.proyecto_fullstack_backend_ut;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoFullstackBackendUtApplicationTests {

	@Test
	void contextLoads() {
	}

}
