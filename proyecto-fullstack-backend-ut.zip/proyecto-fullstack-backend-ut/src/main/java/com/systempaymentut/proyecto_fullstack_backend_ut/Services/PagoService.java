package com.systempaymentut.proyecto_fullstack_backend_ut.Services;

import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.time.LocalDate;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.systempaymentut.proyecto_fullstack_backend_ut.entities.Estudiante;
import com.systempaymentut.proyecto_fullstack_backend_ut.entities.Pago;
import com.systempaymentut.proyecto_fullstack_backend_ut.enums.PagoStatus;
import com.systempaymentut.proyecto_fullstack_backend_ut.enums.TypePago;
import com.systempaymentut.proyecto_fullstack_backend_ut.repository.PagoRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional // para asegurar que los metodos de las clases se ejecuten dentro de una
               // transaccion
public class PagoService {

    // inyecccion de dependencia de PagoRepository para interactuar con la base de
    // pagos
    @Autowired
    private PagoRepository pagoRepository;

    // inyecccion de dependencia de EstudianteRepository para obtener informacion
    // de los estudiantes desde la base de datos
    @Autowired
    private Estudiante estudianteRepository;

    /**
     * metodo para guardar el pago en la base de datos y almacenar un archio pdf en el servidor
     * 
     *@param file archivo pdf que se subira al servidor
     *@param cantidad monto del pago realizado
     *@param type tio de pago EFECTIVO, CHEQUE, TRANSFERENCIA, DEPOSITO
     *@param date fecha en la que se realiza el pago
     *@param codigoEstudiante codigo del estudiante que realiza el pago
     *@return objeto del pago guardado en la base de datos
     * @throws IOException 
     *@throws IOEXception excepcion lanzada si ocurre un error al manejar el archivo pdf
     */

     public Pago savePago(MultipartFile file, double cantidad, TypePago type, LocalDate date, String codigoEstudiante) throws IOException {

        /**
         * construir la ruta donde se guardara el archivo dentro del sistema
         * System.getProperty("user.home"): obtiene la tura de nuestro directorio personal del usuario del actual sistema operativo
         * Paths.get : construir una ruta dentro del directorio personal en la carpeta "enset-data/pagos"
         * 
         */

        Path folderPath = Paths.get(System.getProperty ("user.home"), "enser-data", "pagos");
       
        //verificar si la carpeta ya existe, si no la debe crear
        if(!Files.exists(folderPath)) {Files.createDirectories(folderPath);
        }

        //generamos un nombre unico para el archivo usando UUID (identificador unico universal)
        String fileName = UUID.randomUUID().toString();

        //construimos la ruta completa del archivo agregando la extension .PDF
        Path filePath = Paths.get(System.getProperty ("user.home"), "enset-data", "pagos", fileName + ".pdf");

        //guardamos el archvio recibido en la ubicacion especificada dentro del sistema de archivos
        Files.copy(file.getInputStream(), filePath);
        
        //buscamos el estudiante que realiza el pago con su codigo
        Estudiante estudiante = estudianteRepository.findbyCodigo(codigoEstudiante);

        //creamos un nuevo objeto pago utilizando el patron de diseño builder
        Pago pago = Pago.builder()
        .type(type)
        .status(PagoStatus.CREADO) // estado inicial del pago
        .fecha(date)
        .estudiante(estudiante)
        .cantidad(cantidad)
        .file(filePath.toUri().toString()) //ruta del archivo pdf almacenado
             .build(); //construccion final del objeto de pago

        return pagoRepository.save(pago);

     
    }

    public byte[] getArchivoPorId(Long pagoId) throws IOException {

        // busca un objeto pago en la base de datos por su ID
        Pago pago = pagoRepository.findById(pagoId).get();

        /**
         * pago.getfile: obtiene la URI del archivo guardado como una cadena de texto
         * URI.create: convierte la cadena de texto en un objeto URI
         * path.of: convierte la URI en un path(Carpeta) para poder acceder al archivo
         * Files.readAllBytes: lee el contenido del archivo y lo va a devolver en un
         * array
         * vector de bytes
         * esto va a permitir obtener el contenido del archivo para su posterior uso,
         * descargar
         *
         */
        return Files.readAllBytes(Path.of(URI.create(pago.getFile())));

    }

    public Pago actualizarPagoPorStatus(PagoStatus status, Long id) {

        // busca un objeto pago en la base de datos por su ID
        Pago pago = pagoRepository.findById(id).get();

        // Actualiza el estado del pago (validado, rechazado)
        pago.setStatus(status);

        // guarda el objeto pago actualizado en la base de datos y lo devuelve
        return pagoRepository.save(pago);

    }

}







