package com.systempaymentut.proyecto_fullstack_backend_ut;

import java.time.LocalDate;
import java.util.Random;
import java.util.UUID;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.systempaymentut.proyecto_fullstack_backend_ut.entities.Estudiante;
import com.systempaymentut.proyecto_fullstack_backend_ut.entities.Pago;
import com.systempaymentut.proyecto_fullstack_backend_ut.enums.PagoStatus;
import com.systempaymentut.proyecto_fullstack_backend_ut.enums.TypePago;
import com.systempaymentut.proyecto_fullstack_backend_ut.repository.EstudianteRepository;
import com.systempaymentut.proyecto_fullstack_backend_ut.repository.PagoRepository;

@SpringBootApplication
public class ProyectoFullstackBackendUtApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoFullstackBackendUtApplication.class, args);
	}

	@Bean
	CommandLineRunner CommandLineRunner(EstudianteRepository EstudianteRepository, PagoRepository pagoRepository) {
		return args -> {
			EstudianteRepository.save(Estudiante.builder()
					.id(UUID.randomUUID().toString())
					.nombre("Jessica")
					.apellido("Madrid")
					.codigo("1234")
					.programaId("ISI123")
					.build());

			EstudianteRepository.save(Estudiante.builder()
					.id(UUID.randomUUID().toString())
					.nombre("Carla")
					.apellido("Marquez")
					.codigo("1234")
					.programaId("ISI123")
					.build());

			EstudianteRepository.save(Estudiante.builder()
					.id(UUID.randomUUID().toString())
					.nombre("Camila")
					.apellido("Mendez")
					.codigo("1234")
					.programaId("ISI123")
					.build());

			EstudianteRepository.save(Estudiante.builder()
					.id(UUID.randomUUID().toString())
					.nombre("Sebastian")
					.apellido("Rodriguez")
					.codigo("1234")
					.programaId("ISI123")
					.build());

			EstudianteRepository.save(Estudiante.builder()
					.id(UUID.randomUUID().toString())
					.nombre("Jorge")
					.apellido("Lopez")
					.codigo("1234")
					.programaId("ISI123")
					.build());

			EstudianteRepository.save(Estudiante.builder()
					.id(UUID.randomUUID().toString())
					.nombre("Wilson")
					.apellido("Ospina")
					.codigo("1234")
					.programaId("ISI123")
					.build());

			// Obtener tipos de pagos diferentes para cada estudiante
			TypePago tiposPago[] = TypePago.values();

			Random random = new Random();

			EstudianteRepository.findAll().forEach(estudiante -> {

				for (int i = 0; i < 10; i++) {
					int index = random.nextInt(tiposPago.length);

					// Construir un objeto pago con valores aleatorios
					Pago pago = Pago.builder()
							.cantidad(1000 + (int) (Math.random() * 20000))
							.type(tiposPago[index])
							.status(PagoStatus.CREADO)
							.fecha(LocalDate.now())
							.estudiante(estudiante)
							.build();

					pagoRepository.save(pago);

				}
			});

		};

	}

}
