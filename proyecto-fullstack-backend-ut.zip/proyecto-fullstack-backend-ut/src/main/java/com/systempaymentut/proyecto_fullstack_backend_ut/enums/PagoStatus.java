package com.systempaymentut.proyecto_fullstack_backend_ut.enums;

public enum PagoStatus {
    
    CREADO, VALIDADO, RECHAZADO

}
