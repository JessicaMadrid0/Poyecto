package com.systempaymentut.proyecto_fullstack_backend_ut.enums;

public enum TypePago {

    EFECTIVO, CHEQUE, TRANSFERENCIA, DEPOSITO
    
}
